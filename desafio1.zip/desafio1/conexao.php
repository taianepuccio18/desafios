<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "desafio1";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);


	?>