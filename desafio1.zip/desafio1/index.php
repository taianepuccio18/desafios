<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial</title>

<style>

input{
    font: normal 15pt Arial;
    background-color: white;
    margin: auto;
    border-radius: 10px;
    margin-top: 5px;
    
}
body{
    background-image: url(fundo2.jpg);
    font: normal 18pt Arial;
}
header{
    color: white;
    text-align: center;

}

footer{
    color: white;
    text-align: center;

}
.botão{
    font: normal 18pt Arial;
    background-color: white;
    margin: auto;
    border-radius: 10px;
    margin-top: 12px;
}
section{
    background: white;
    border-radius: 10px;
    padding: 15px;
    width: 420px;
    height:850px;
    margin: auto;
    box-shadow: 5px 5px 10px rgb(54, 53, 53);

}
</style>
    
</head>
<body>
<header>
        
        <p></p>
    </header>
    <section>
    <center>

    <h1 id="h">Página Inicial</h1>
    <form method='post' action='processa.php'>
    <center>Qual sua faixa de Idade: <br> <input type='radio' name='idade' value='30'> Até 30 anos <br>
    <input type='radio' name='idade' value='de 30 a 50'>De 30 a 50 anos <br>
    <input type='radio' name='idade' value='de 50 a 65'> De 50 a 65 anos <br>
    <input type='radio' name='idade' value='acima de 65'>Acima de 65 anos </center>

    <br>

    <center>Qual seu convênio: <br> <input type='radio' name='convenio' value='inss'> INSS <br>
    <input type='radio' name='convenio' value='siape'> SIAPE <br>
    <input type='radio' name='convenio' value='forças armadas'> Forças Armadas <br>
    <input type='radio' name='convenio' value='outros'> Outros </center>

    <br>

    <center>Qual sua faixa salarial: <br> <input type='radio' name='fsalarial' value='2sm'> Até 2 SM <br>
    <input type='radio' name='fsalarial' value='2 a 4 sm'> De 2 a 4 SM <br>
    <input type='radio' name='fsalarial' value='4 a 6 sm'> De 4 a 6 SM <br>
    <input type='radio' name='fsalarial' value='acima de 6m'> Acima de 6M </center>


    <br>

    <center>Por que você realizou o empréstimo: <br>

    <input type='checkbox' name='motivo' value='pagar contas'> Pagar contas <br>

     <input type='checkbox' name='motivo' value='Reforma da casa'> Reforma da casa <br>
        
    <input type='checkbox' name='motivo' value=' Compra de carro'> Compra de carro <br>
        
     <input type='checkbox' name='motivo' value='outras'> Outras <br>
    
    </center>

    <br>

    <center><input type='submit' value='Salvar' name='botao'></center>

    
        
    </form>
    </center>
    </section>
    <footer>
    <center>
        
        </center>
    </footer>

</body>
</html>