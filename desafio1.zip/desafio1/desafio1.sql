-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05-Jul-2021 às 13:30
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Banco de dados: `desafio1`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `perguntas`
--

CREATE TABLE `perguntas` (
  `pergunta` varchar(40) NOT NULL,
  `opcao1` varchar(40) NOT NULL,
  `opcao2` varchar(40) NOT NULL,
  `opcao3` varchar(40) NOT NULL,
  `opcao4` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `perguntas`
--

INSERT INTO `perguntas` (`pergunta`, `opcao1`, `opcao2`, `opcao3`, `opcao4`) VALUES
('Por que você realizou o empréstimo', 'Pagar contas', 'Reforma da casa', 'Compra de carro', 'Outras'),
('Qual seu convênio', 'INSS', 'SIAPE', 'Forças Armadas', 'Outros'),
('Qual sua faixa de Idade', 'Até 30 Anos', 'De 30 a 50 anos', 'De 50 a 65 anos', 'Acima de 65 anos'),
('Qual sua faixa salarial', 'Até 2 SM', 'De 2 a 4 SM', 'De 4 a 6 SM', 'Acima de 6 SM');

-- --------------------------------------------------------

--
-- Estrutura da tabela `respostas`
--

CREATE TABLE `respostas` (
  `idade` varchar(20) NOT NULL,
  `convenio` varchar(20) NOT NULL,
  `fsalarial` varchar(20) NOT NULL,
  `motivo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `respostas`
--

INSERT INTO `respostas` (`idade`, `convenio`, `fsalarial`, `motivo`) VALUES
('30', 'inss', '2 a 4 sm', 'Reforma da casa'),
('30', 'inss', '2 a 4 sm', 'Reforma da casa'),
('30', 'inss', '2 a 4 sm', 'Reforma da casa'),
('30', 'inss', '2 a 4 sm', ' Compra de carro');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `perguntas`
--
ALTER TABLE `perguntas`
  ADD PRIMARY KEY (`pergunta`);


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata para tabela perguntas
--

--
-- Metadata para tabela respostas
--

--
-- Metadata para o banco de dados desafio1
--
COMMIT;
