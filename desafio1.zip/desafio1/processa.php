<?php
session_start();
include_once("conexao.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Treino</title>
</head>
<body>
    
</body>
</html>
    <style>
input{
    font: normal 15pt Arial;
    background-color: white;
    margin: auto;
    border-radius: 10px;
    margin-top: 5px;
    
}
body{
    background-image: url(fundo9.jpeg);
    font: normal 18pt Arial;
}
header{
    color: black;
    text-align: center;
    
    
}

footer{
    color: white;
    text-align: center;

}
.botão{
    font: normal 18pt Arial;
    background-color: white;
    margin: auto;
    border-radius: 10px;
    margin-top: 12px;
}
section{
    background: white;
    border-radius: 10px;
    padding: 15px;
    width: 400px;
    height: 1270px;
    margin: auto;
    box-shadow: 5px 5px 10px rgb(54, 53, 53);
}
    
    
}

</style>
    
</head>
<body>
<center>
<h1 id="h">Informações salvas com sucesso!</h1>

<a href='index.php'><button class= "botão">Início</button></a>

</center>
<?php

$idade = $_POST['idade'];
$convenio = $_POST['convenio'];
$fsalarial = $_POST['fsalarial'];
$motivo = $_POST['motivo'];



$sql = "INSERT INTO respostas (idade, convenio, fsalarial, motivo) VALUES ('$idade', '$convenio', '$fsalarial','$motivo')";

if (mysqli_query($conn, $sql)) {
    echo "";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);


?>

</body>
</html>


